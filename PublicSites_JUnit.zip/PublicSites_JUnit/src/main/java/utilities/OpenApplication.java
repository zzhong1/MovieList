package utilities;

import org.finra.automation.radautomationcommon.command.GlobalContextManager;
import org.finra.jtaf.ewd.ExtWebDriver;
import org.finra.jtaf.ewd.session.SessionManager;
import org.finra.junit.base.BaseTest;

import qc.automation.framework.properties.PropertiesReader;

public class OpenApplication {
	public static void open(String url) throws Exception{
		RunConfigManager runConfig= BaseTest.getRunConfig();
		ExtWebDriver ewd = SessionManager.getInstance().getNewSession("client", runConfig.getClientFilePath());
		ewd.open(runConfig.getApplicationUrl(url));
		
		ewd.getWrappedDriver().manage().window().maximize();
	
	}

}
