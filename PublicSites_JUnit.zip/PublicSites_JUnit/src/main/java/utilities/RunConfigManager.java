package utilities;

import java.io.IOException;

import org.apache.log4j.Logger;



public class RunConfigManager
{	
	private static final String RUN_CONFIG_PROPERTIES_FILE_NAME = "profiles/runconfig.properties";
	final static Logger logger = Logger.getLogger(RunConfigManager.class);
	private static final String CLIENT_PROPERTY_KEY = "client";
	private static final String TARGET_PROPERTY_KEY = "target";
	private static final String USER_PROPERTY_KEY="users";
	private static final String DB_NAME_KEY = "main";
	private  PropertyFetcher testConfigPropertyFetcher;
	private  PropertyFetcher targetPropertyFetcher;
	private  PropertyFetcher userPropertyFetcher;
	private  PropertyFetcher clientPropertyFetcher;
	

	public RunConfigManager() throws IOException
	{
		this(RUN_CONFIG_PROPERTIES_FILE_NAME);
	}
	public Logger getLogger()
	{
		return logger;
	}
	
	public RunConfigManager(String runConfigPropertiesFileName) throws IOException
	{
		if(runConfigPropertiesFileName != null)
			testConfigPropertyFetcher = new PropertyFetcher(runConfigPropertiesFileName);
		String target = getPropertyFromSystemOrFile(TARGET_PROPERTY_KEY);
			targetPropertyFetcher = new PropertyFetcher(target);
		String user=getPropertyFromSystemOrFile(USER_PROPERTY_KEY);
			userPropertyFetcher = new PropertyFetcher(user);
		String client=getPropertyFromSystemOrFile(CLIENT_PROPERTY_KEY);
			clientPropertyFetcher = new PropertyFetcher(client);
	}
	public String getPropertyFromSystemOrFile(String propertyKey)
	{
		String systemProperty = System.getProperty(propertyKey);
		if(systemProperty != null)
			return systemProperty;
		
		if(testConfigPropertyFetcher != null)
			return testConfigPropertyFetcher.fetchString(propertyKey);
		
		return null;
	}

	public String getClientFilePath()
	{
		return getPropertyFromSystemOrFile(CLIENT_PROPERTY_KEY);
	}

	public String getApplicationUrl(String URL_PROPERTY_KEY)
	{
		return targetPropertyFetcher.fetchString(URL_PROPERTY_KEY);
	}

	public String getDbName()
	{
		return targetPropertyFetcher.fetchString(DB_NAME_KEY);
	}
	
	public String getUserPrefix(String userPrefix)
	{
		return userPropertyFetcher.fetchString(userPrefix);
	}
	
	public PropertyFetcher getClientPropertyFetcher() {
		return clientPropertyFetcher;
	}
	
	public String isPasswordEncoded(String passwordEncoded)
	{
		return userPropertyFetcher.fetchString(passwordEncoded);
	}
	
	
	
}
