package org.finra.iapd;


import org.finra.jtaf.ewd.widget.element.Element;
import org.finra.junit.base.BaseTest;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utilities.OpenApplication;

/**
 * @author K25032
 *
 */
public class verifyAllLinks {

	@Rule
	public BaseTest basetest=new BaseTest();
	
	//verify all links on IAPD Landing Page
	@Test
	public void verifyLandingPageLinks() throws Exception {
		OpenApplication.open("IAPD.url");
		Element el = new Element("/");
		WebDriver driver = el.getGUIDriver().getWrappedDriver();
		
		//Verify Resource link on left navigation
		driver.findElement(By.partialLinkText("Resources")).click();
		String source = driver.getPageSource();
		String SECText = "U.S. Securities and Exchange Commission";
		String NASAAText = "North American Securities Administrators Association";
		String FinraText = "Financial Industry Regulatory Authority";
		Assert.assertTrue("Resource Page link broken, no "+ SECText + "text found ", (source.contains(SECText)));
		Assert.assertTrue("Resource Page link broken, no "+ NASAAText +" text found ", (source.contains(NASAAText)));
		Assert.assertTrue("Resource Page link broken, no "+ FinraText +" text found ", (source.contains(FinraText)));
		driver.navigate().back();
		
		//Verify Investment Adviser Data Link on Left Navigation
		driver.findElement(By.linkText("Investment Adviser Data"));
		// add verification here
		
		//Verify Investment Adviser Search link on left navigation
		driver.findElement(By.linkText("Investment Adviser Search")).click();
		//add verification here		
	}
	
	/*@Test
	public void verifyIndvlSummuryLinks() throws Exception {
	
	}

	@Test 
	public void verifyFirmSummurtLinks() throws Exception {
		
	}
	
	@Test 
	public void verifyADVPageLinks() throws Exception {
		
	}
	
	@Test
	public void verifyPart2BrochurePageLinks() throws Exception {
		
	}*/
	
}
