package org.finra.iapd;

import static org.junit.Assert.*;

import org.finra.junit.base.BaseTest;
import org.junit.Rule;
import org.junit.Test;

import utilities.OpenApplication;

public class SampleTest {
	@Rule
	public BaseTest basetest=new BaseTest();
	@Test
	public void verifyCurrentEmployers() throws Exception {
		OpenApplication.open("IAPD.url");
	}


}
