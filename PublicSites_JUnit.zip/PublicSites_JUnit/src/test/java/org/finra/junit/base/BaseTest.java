package org.finra.junit.base;


import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.finra.jtaf.ewd.ExtWebDriver;
import org.finra.jtaf.ewd.session.SessionManager;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import utilities.OpenApplication;
import utilities.RunConfigManager;



public class BaseTest extends TestWatcher{

	public static RunConfigManager runConfig;
	private String testTime;
	private Logger logger=Logger.getLogger(BaseTest.class);
	
	@Override
	protected void starting(Description description)
	{
		try
		{
		runConfig = new RunConfigManager();
		System.setProperty("strategy", "N/A");
		System.setProperty("target", runConfig.getPropertyFromSystemOrFile("target"));
		System.setProperty("users",	runConfig.getPropertyFromSystemOrFile("users"));
		System.setProperty("client", runConfig.getPropertyFromSystemOrFile("client"));
		
		testTime = new SimpleDateFormat("yyyy_MM-dd_HH_mm_ss").format(Calendar.getInstance().getTime());
			
		logger.info(description.getClassName() + '.' + description.getMethodName());
		logger.info(String.format("---------------------------- TEST BEGINS at %s----------------------------",testTime));
		logger.info(String.format("Test name: %s", description.getDisplayName()));
		
			
			
		}
		catch(IOException exception)
		{
			throw new RuntimeException("Problem while trying to begin test", exception);
		}
	}
	
	@Override
	public void failed(Throwable e, Description test) {
		
			ExtWebDriver extWebDriver = SessionManager.getInstance()
					.getCurrentSession(false);
			if (extWebDriver == null) {
				System.out
						.println("Could not save screenshot because there was no current EWD session");
				return;
			}
			File screenshotFile = ((TakesScreenshot) extWebDriver.getWrappedDriver()).getScreenshotAs(OutputType.FILE);
			File outputFile = new File("extensions/" + test.getMethodName() + ".jpg");
			logger.info(String.format("Test Failed: %s Screenshot added in extensions folder", test.getDisplayName()));
			try {
			FileUtils.copyFile(screenshotFile, outputFile);
		} catch (IOException e1) {
			throw new RuntimeException("Problem while copying screenshot to file", e1);
		}
	}
	

	@Override
	public void finished(Description description)
	{
		logger.info(String.format("Test name: %s", description.getDisplayName()));
		logger.info("-------------------------------- TEST ENDS --------------------------------");
		ExtWebDriver extWebDriver = SessionManager.getInstance().getCurrentSession(false);
		extWebDriver.quit(); 
		extWebDriver=null;
		 
	}
	
	
	public static RunConfigManager getRunConfig() {
		return runConfig;
	}

}
