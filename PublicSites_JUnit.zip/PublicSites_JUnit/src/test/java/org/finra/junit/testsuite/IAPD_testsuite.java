package org.finra.junit.testsuite;

import org.finra.iapd.verifyAllLinks;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
	verifyAllLinks.class
	})
public class IAPD_testsuite {

}
