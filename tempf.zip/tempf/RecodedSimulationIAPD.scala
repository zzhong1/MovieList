package test14
import IAPD._
import CRD_Brokercheck._
import ReportGeneration._
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.core.scenario.Simulation
/**
  * Created by K25032 on 12/23/2015.
  */
class RecodedSimulationIAPD extends Simulation{

  val crd_url = "https://crd-int2.dev.finra.org"

  val httpProtocol = http
    .baseURL("https://crd-int2.dev.finra.org")
    .acceptHeader( """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""")
    .acceptEncodingHeader( """gzip, deflate, sdch""")
    .acceptLanguageHeader( """en-US,en;q=0.8""")
    .connection( """keep-alive""")
    .contentTypeHeader( """application/x-www-form-urlencoded""")
    .doNotTrackHeader( """1""")
    .userAgentHeader( """Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.91 Safari/537.36""")
  .disableResponseChunksDiscarding
  val crdIndvlSearch = scenario("crd indvl search")
  .exec(CRD.scn_FIRM_ViewIndvl_With_Org)
val indvlReport = scenario("view indvl report iapd")
  .exec(ReportGeneration.view_indvl_report)
  //indvl name only search
  val indvlOnly = scenario("Indvl Search Only")
    .exec(IAPD.scn_IAPD_IndvlSearchonly)
  //different type search once per user
  val indvl = scenario("indvl search and report")
    .exec(IAPD.scn_IAPD_IndvlSearch)
  //muti params search
  val indvlSearchMulParams = scenario("Indvl Search with Multiple Parameters")
    .exec(IAPDIndvlSrch_Searchrequest_NOreport)

  //multiple params search without view all sections
  val firmSearch = scenario("Firm search and view detials")
    .exec(IAPD.snc_IAPD_FirmSearch)

  //multiple params search with view all sections
  val firmSearchWithADV = scenario("firm search with view ADV All Sections")
    .exec(IAPD_Firm)

  val seo = scenario("SEO IAPD")
  .exec(IAPD_SEO)

  val validate_url = scenario("indvl pagination")
  .exec(pagination_indvl)

  val sno_FirmSrch_ByBdOrgNm_Zip = scenario("IndvlSearch_ByIndvl_PK")
  .exec(homepage)
    .exec(FirmSrch_ByBdOrgNm_Zip)

  val sno_IndivSrch_ByIndvlNm = scenario("IndivSrch_ByIndvlNm")
  .exec(Regular_FirmSearch_Script)

    val indvl_pdf = scenario("view indvl report with drps")
  .exec(Indvl_ReportStatusLinks_Scrapping_QCR)
  val firm_pdf = scenario("view firm report with drps")
  .exec(Firm_BigDownloadPDF_QCR)
  val indvl_pdf_bc = scenario("view indvl report with drp on bc")
  .exec(BC_indvl_searchreport_QCR)
  val firm_pdf_bc = scenario("view firm pdf with drp on bc")
  .exec(BC_Firm_searchreport_QCR)
  //setUp(indvlOnly.inject(atOnceUsers(1))).protocols(httpProtocol)
  setUp(crdIndvlSearch.inject(atOnceUsers(1))).protocols(httpProtocol)

}

/*

INDVL

1)Search only - Different combination
name only
id only
name zip
zip only
firnname zip

2) search with report
Search multiple way - Use 2 or 3 ways
eithr ID , Zip or name of indvl
Download report

3)  search with report
Search multiple way - Use 2 or 3 ways
eithr ID , Zip or name of indvl
IA indvl links
BC indvl Links





FIRM Search

1)Search only - Different combination
name only
id only
name zip
zip only
firnname zip

2) search with report
Search multiple way - Use 2 or 3 ways
eithr ID , Zip or name of indvl
Download report

3) download pdf for the existing id in db

4) adv all sections



 */