package test14

import _root_.io.gatling.core.scenario.Simulation
import com.typesafe.config.ConfigFactory
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import CRD._
import IAPD._
import CRD_Brokercheck._
class RecordedSimulation extends Simulation {

	// this is the Config file for the IAPD - setting up url , duration etc.
	/* parameters list (config)*/

	val config = ConfigFactory.load("IAPD.conf")
	val IAPD_url = config.getString("IAPD_URL")
	val BC_URL = config.getString("BC_URL")
	val totaltimefortest = config.getInt("TotalDuration")
	val crd_url = "https://crd-int2.dev.finra.org"
	//val crd_publicsite_scenario = config.getString("scenario_execution")
	val crd_publicsite_scenario = "QCR"

	val httpProtocol_CRDpublicSite = http
			.baseURL(crd_url)
			.acceptHeader( """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""")
			.acceptEncodingHeader( """gzip, deflate, sdch""")
			.acceptLanguageHeader( """en-US,en;q=0.8""")
			.connection( """keep-alive""")
			.contentTypeHeader( """application/x-www-form-urlencoded""")
			.doNotTrackHeader( """1""")
			.userAgentHeader( """Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.91 Safari/537.36""")

	val httpScenarios = Map (
		"QCR"-> List(

/*
			IAPD.scn_IAPD_Firm_BigDownloadPDF_QCR.inject(rampUsers(1000)over(1800)), // run on 2 machine  so per hour 10,000/hr
*/
			IAPD.scn_IAPD_IndvlDownloadReport_Scrapping_QCR.inject(rampUsers(1000)over(3000)), // run on 2 machine  so per hour 10,000/hr
			IAPD.scn_BC_IndvlSearchReport_QCR.inject(rampUsers(1000)over(3000)), // run on 2 machine  so per hour 10,000/hr
			IAPD.scn_BC_FirmSearchReport_QCR.inject(rampUsers(1000)over(3000)), // run on 2 machine  so per hour 10,000/hr
			IAPD.scn_BC_IndvlSummaryDisclosureLinks.inject(rampUsers(1000)over(3000))
		)
	)
	val crdSearchNameScenarios = Map(
		"INT2"-> List(
		CRD.scn_FIRM_ViewIndvl_With_Org.inject(rampUsers(1000)over(1800))
		)
	)
	setUp(httpScenarios(crd_publicsite_scenario):_*).protocols(httpProtocol_CRDpublicSite).assertions(global.successfulRequests.percent.is(100))
}