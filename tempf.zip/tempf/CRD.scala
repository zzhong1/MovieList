package test14
import com.typesafe.config.ConfigFactory

import io.gatling.http.Predef._
import io.gatling.http.check.HttpCheck
import Login._
import java.util.{Date, Calendar}

import java.util.{Calendar, Date}
import io.gatling.core.Predef._

import scala.collection.mutable.ArrayBuffer
import scala.concurrent.forkjoin.ThreadLocalRandom
/**
  * Created by K25032 on 2/22/2016.
  */
object CRD {

  val FIRMUser_ViewIndvl = csv("data/CRD/Search/FirmUser_IndSearchView.txt").random
  val nameWithOrgPK = csv("data/CRD/Search/nameWithOrgPK.txt").random


  val scn_FIRM_ViewIndvl = scenario("FIRM_ViewIndvl_temp")
    .exitBlockOnFail{
      feed(FIRMUser_ViewIndvl)
        .exec(Login.CRD_Login("ARTFINRAJR"))
        .exec(CRD.FirmUser_ViewIndvl("${INDVLID}"))
    }

  val scn_FIRM_ViewIndvl_With_Org = scenario("FIRM_ViewIndvl_temp")
    .exitBlockOnFail{
      feed(nameWithOrgPK)
        .exec(Login.CRD_Login("ARTFINRAJR"))
        .exec(CRD.U5_Partial())
    }
  def FirmUser_ViewIndvl(Individual_PK: String = "Smith") = {
    exec(http("CRD_Search")
      .get("/pgm/search/crd_pgm_searchvii.aspx?System=CRD")
    )
      .pause(1, 5)
      .exec(http("CRD_Individual_Search ")
        .get("/PGM/Search/CRD_PGM_SearchVII.aspx")
        .check(regex( """VIEWSTATE" value="(.*?)"""").find.optional.saveAs("viewstate"))
        .check(regex( """VIEWSTATEGENERATOR" value="(.*)"""").find.optional.saveAs("viewstate_generator"))
        .check(regex( """EVENTVALIDATION" value="(.*)"""").find.optional.saveAs("EventValidation"))
      )
      .pause(1, 5)
      .exec(http("CRD_Individual_SearchviaOtherName")
        .post("/PGM/Search/CRD_PGM_SearchVII.aspx")
        .headers(Map("Accept-Encoding" -> "gzip, deflate", "Cache-Control" -> "max-age=0"))
        .formParam("__EVENTTARGET", "")
        .formParam("__EVENTARGUMENT", "")
        .formParam("ctl00_cphMainContent_ScriptManager1_HiddenField", "")
        .formParam("ctl00_cphMainContent_ucIndvlSearchCriteria_TabContainer1_ClientState", """{"ActiveTabIndex":0,"TabState":[true,true,true]}""")
        .formParam("__VIEWSTATE", """${viewstate}""")
        .formParam("__VIEWSTATEGENERATOR", """${viewstate_generator}""")
        .formParam("__EVENTVALIDATION", "${EventValidation}")
        .formParam("ctl00$cphMainContent$ScriptManager1", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanel1$txtShortsearch", Individual_PK)
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanel1$btnSubmit", "Search")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanel1$TBWE2_ClientState", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanel2$txtCrdNumber", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanel2$txtSsnNumber", "___-__-____")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanel2$MaskedEditExtender2_ClientState", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanel2$txtName", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanel2$txtFirmName", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanel2$txtFirmCrdNumber", "")
        /*.formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanelPreRegistration$txtPreRegCrdNumber", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanelPreRegistration$txtPreRegSsnNumber", "___-__-____")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanelPreRegistration$MaskedEditExtender3_ClientState", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanelPreRegistration$txtPreRegName", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanelPreRegistration$txtVerifySSN", "___-__-____")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanelPreRegistration$txtSSN_MaskedEditExtender_ClientState", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanelPreRegistration$txtBirthMonthDay", "__/__")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanelPreRegistration$MaskedEditExtender1_ClientState", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearchCriteria$TabContainer1$TabPanelPreRegistration$cpe_ClientState", "true")
        .check(regex("No records found matching your current search").find.optional.saveAs("NOResults"))*/
        .check(regex( """System Error(.*)""").find.optional.saveAs("SYS_Error")))
      .pause(1, 5)
      .exec(session => if (!session.contains("SYS_Error")) session else session.markAsFailed)
      .exec(session => if (!session.contains("NOResults")) session else session.markAsFailed)
      //   //   .exitHereIfFailed

  }
  def U5_Partial(str1: String = "firm") = {

      exec(http("U5_PATIAL")
        .get("/PGM/Search/crd_pgm_SearchIndFRM.aspx?Form=U5&Type=PARTIAL&System=CRD")
        .check(regex( """__VIEWSTATE" value="(.*?)"""").find.optional.saveAs("viewstate"))
        .check(regex( """__EVENTVALIDATION" value="(.*?)"""").find.optional.saveAs("EventValidation"))
        .check(regex( """__VIEWSTATEGENERATOR" value="(.*?)"""").find.optional.saveAs("viewstate_generator")))
      .pause(3, 7)
      .exec(http("U5_Indvl_Search")
        .post("/PGM/Search/crd_pgm_SearchIndFRM.aspx?Form=U5&Type=PARTIAL&System=CRD").formParam("__EVENTTARGET", "")
        .formParam("__EVENTARGUMENT", "")
        .formParam("__VIEWSTATE", """${viewstate}""")
        .formParam("__VIEWSTATEGENERATOR", """${viewstate_generator}""")
        .formParam("__EVENTVALIDATION", "${EventValidation}")
        .formParam("ctl00$cphMainContent$ucIndvlSearch$txtFirmCrd", "${org_pk}")

        .formParam("ctl00$cphMainContent$ucIndvlSearch$txtIndvlCrd", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearch$txtSearchSSN", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearch$txtSearchLastName", "${last_nm}")
        .formParam("ctl00$cphMainContent$ucIndvlSearch$txtSearchFirstName", "${first_nm}")
        .formParam("ctl00$cphMainContent$ucIndvlSearch$txtSearchMidName", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearch$txtSearchBirthDt", "")
        .formParam("ctl00$cphMainContent$ucIndvlSearch$btnSearch", " Search ")
        .formParam("ctl00$cphMainContent$ucIndvlSearch$hdnDupMatch", "")
       )
  }
  def U5Forms() = {
    exec(http("CRDHome_Filings")
      .get("/crdmain/crd_man_redirect.aspx?redirect=FILINGTYPES"))
      .pause(2,5)
      .exec(http("U5Filing")
        .get("/pgm/search/crd_pgm_searchfilingtypes.aspx?Form=U5"))
      .pause(2,5)
      .exec(http("U5Partial")
        .get("/PGM/Search/CRD_PGM_SearchIndFRM.aspx?Form=U5&Type=PARTIAL&System="))
      .pause(1, 5)
      .exec(http("U5Partial_SearchIndvl")
        .post("/PGM/Search/CRD_PGM_SearchIndFRM.aspx?Form=U5&Type=PARTIAL")
        .formParam("INDVL_PK", "")
        .formParam("SSN_NB", "")
        .formParam("LAST_NM", "")
        .formParam("FIRST_NM", "")
        .formParam("MID_NM", "")
        .formParam("txtBirthDate", "")
        .formParam("txtMaxRows", "25")
        .formParam("System", "CRD")
        .formParam("SearchType", "U5")
        .formParam("Action", "Search")
        .formParam("cmdProcess", "Query")
      )

  }



    val CommonChecks: Seq[HttpCheck] = Seq(
    regex( """VIEWSTATE" value="(.*)"""").find.optional.saveAs("viewstate"),
    regex( """VIEWSTATEGENERATOR" value="(.*)"""").find.optional.saveAs("viewstate_generator"),
    regex( """EVENTVALIDATION" value="(.*)"""").find.optional.saveAs("EventValidation"))
  //  regex("System Error").notExists)

  private val CommonChecks_IAPD: Seq[HttpCheck] = Seq(
    regex( """VIEWSTATE" value="(.*?)"""").find.optional.saveAs("viewstate"),
    regex( """VIEWSTATEGENERATOR" value="(.*?)"""").find.optional.saveAs("viewstate_generator"),
    regex( """EVENTVALIDATION" value="(.*?)"""").find.optional.saveAs("EventValidation")
  )
  val CommonChecks_2: Seq[HttpCheck] = Seq(regex("VIEWSTATE\\|(.*?)\\|").find.saveAs("viewstate"),
    regex("VIEWSTATEGENERATOR\\|(.*?)\\|").find.saveAs("viewstate_generator"),
    regex("EVENTVALIDATION\\|(.*?)\\|").find.saveAs("EventValidation"))
  //  regex("System Error").notExists)
  val headers_52 = Map("Accept-Encoding" -> "gzip, deflate", "Cache-Control" -> "max-age=0")

}
