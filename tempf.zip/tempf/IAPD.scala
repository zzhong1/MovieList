package test14

import com.typesafe.config.ConfigFactory

import io.gatling.http.Predef._
import io.gatling.http.check.HttpCheck

import java.util.{Date, Calendar}

import java.util.{Calendar, Date}
import io.gatling.core.Predef._

import scala.concurrent.forkjoin.ThreadLocalRandom

object IAPD{
  val headers_0 = Map("Upgrade-Insecure-Requests" -> "1")
  val url: String = ""
  val headers_1 = Map(
    "Accept" -> "text/css,*/*;q=0.1",
    "X-DevTools-Emulate-Network-Conditions-Client-Id" -> "96EC062F-A7E7-4226-813B-4B3CB3B17E5B")

  val headers_3 = Map(
    "Accept" -> "*/*",
    "X-DevTools-Emulate-Network-Conditions-Client-Id" -> "96EC062F-A7E7-4226-813B-4B3CB3B17E5B")

  val headers_4 = Map(
    "Origin" -> "http://iapd-int.dev.finra.org",
    "X-DevTools-Emulate-Network-Conditions-Client-Id" -> "96EC062F-A7E7-4226-813B-4B3CB3B17E5B")

  val headers_8 = Map(
    "Accept" -> "image/webp,image/*,*/*;q=0.8",
    "Proxy-Connection" -> "keep-alive")

  val headers_9 = Map(
    "Accept-Encoding" -> "gzip, deflate",
    "Cache-Control" -> "max-age=0",
    "Origin" -> "http://iapd-int.dev.finra.org",
    "Upgrade-Insecure-Requests" -> "1")
  // loading values from the configuration files - account.conf
  val headers_10 = Map("X-DevTools-Emulate-Network-Conditions-Client-Id" -> "96EC062F-A7E7-4226-813B-4B3CB3B17E5B")

  val uri4 = "http://iapd-int.dev.finra.org"
  val configfile = ConfigFactory.load("IAPD.conf")
  //val IAPD_url = """http://iapd-int.dev.finra.org"""
 val BC_url = configfile.getString("BC_URL")
  val IAPD_url = configfile.getString("IAPD_URL")
  val   IAPD_url_QCR = /*"http://iapd-qa2.qa.finra.org"*/"http://iapd-int2.dev.finra.org"
  val BC_url_QCR = /*"http://fbc-qa2.qa.finra.org"*/"http://fbc-int2.dev.finra.org"
  val passwordQCR = "qcapriltesting"
  // this is the feeder for the IAPD_Firm
  /* parameters list (feeders)*/

  val feeder_IPAD_Firm_data = ssv("data/IAPD/IAPD_FirmSearchdoc.txt").random
  val feeder_IPAD_Indvl_data =  ssv("data/IAPD/IPAD_Indvliddoc.txt").random
  val feeder_IAPD_Indvl_search = csv("data/BrokerCheck/BC_searchterm.txt").random
  val feeder_IAPD_Indvlfirm_search = ssv("data/BrokerCheck/IndvlSrch_Data.txt").random
  val feeder_Indvdata = ssv("data/IAPD/Indvl_Searchdata.txt").random
  val feeder_urls = csv("data/IAPD/urls.txt").queue
  val feeder_indvlReportLinkIds_qcr=csv("data/qcr/IAindvl_drp.txt").random
  val feeder_bigdownloadpdfFirmIds_QCR=csv("data/qcr/IAfirm_drp.txt").random
  val feeder_BC_FirmSearch_QCR = csv("data/qcr/BCfirm_drp.txt").random
  val feeder_BC_IndvlSearch_QCR = csv("data/qcr/BCindvl_drp.txt").random
  /* common checks for the scripts*/

  private val CommonChecks_IAPD: Seq[HttpCheck] = Seq(
    regex( """VIEWSTATE" value="(.*?)"""").find.optional.saveAs("viewstate"),
    regex( """VIEWSTATEGENERATOR" value="(.*?)"""").find.optional.saveAs("viewstate_generator"),
    regex( """EVENTVALIDATION" value="(.*?)"""").find.optional.saveAs("EventValidation")
  )
  private val CommonChecks_IAPD_FirmSearch: Seq[HttpCheck] = Seq(
    regex( """No match has been found""").find.optional.saveAs("NoMatchFound_count"),
    regex( """Please enter a valid 5 digit zip code""").find.optional.saveAs("InvalidZip_count"),
    regex( """You must enter a valid search criteria""").find.optional.saveAs("InvalidSrchCriteria_count"),
    regex( """IAPD - Investment Adviser Search Results""").find.optional.saveAs("SrchRsltsPg_count"),
    regex( """.errormessage = "(.*)"""").find.optional.saveAs("gErrorMsg"),
    regex( """IndividualID=-1&Source=Summary&FirmID="(\d+)""""").findAll.optional.saveAs("gBC_ORG_PK"),
    //regex( """SearchGroup=Firm&FirmKey=(\d+)&""").findAll.optional.saveAs("gIA_ORG_PK"),
    regex( """IAPDFirmSummary\.aspx\?ORG_PK=(\d*?)">""").findAll.optional.saveAs("gIA_ORG_PK"),

    regex( """</b> ((\d+?))""").findAll.optional.saveAs("Firm_pk"),
    regex("""View latest Form ADV filed""").find.optional.saveAs("ADV_PDF"),
    regex("""This adviser is also a""").find.optional.saveAs("nbc_firm")
  )


  private val headers_bcsearch = Map("""Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""",
    """Accept-Encoding""" -> """gzip, deflate""",
    """Cache-Control""" -> """max-age=0""",
    """Origin""" -> BC_url,
    """Content-Type""" -> """application/x-www-form-urlencoded""",
    """Referer""" -> BC_url
  )

  val header_IapdInvlsearch = Map("""Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""","""Accept-Encoding""" -> """gzip, deflate""","""Cache-Control""" -> """max-age=0""",
    """Origin""" -> IAPD_url)

  private val CommonChecks_IAPD_IndvlSearch: Seq[HttpCheck] = Seq(
    css("a[id]", "id").findAll.optional.saveAs("gIAIndvl_Ctrl"),
    regex( "IAPDIndvlSummary\\.aspx\\?INDVL_PK=(.*)\">").findAll.optional.saveAs("IAPD_IDLists"),
   // regex( """IndividualID=(.*?)&Source=Summary'""").findAll.optional.saveAs("gIAIndvl_Ctrl_BC"),

  regex( """IndividualID=(.*?)&amp;Source=Summary""").findAll.optional.saveAs("gIAIndvl_Ctrl_BC"),

  regex( """no results were found""").find.optional.saveAs("NoMatchFound_count"),
    regex( """Please enter a valid 5 digit zip code""").find.optional.saveAs("InvalidZip_count"),
    regex( """You must enter a valid search criteria""").find.optional.saveAs("InvalidSrchCriteria_count"),
    regex( """Investment Adviser Search Results""").find.optional.saveAs("SrchRsltsPg_count"),
    regex( """.errormessage = "(.*)"""").find.optional.saveAs("gErrorMsg")
  )



  //  /**
  //   * Creates a scenario by given, name, feed and executions.
  //   * @param name Scenario name
  //   * @param feed Feed used to put data into session
  //   * @param chains Executable that are chained together
  //   * @return
  //   */

  /* MAIN Search for the IAPD - FIRMS */

  private val search_IAPD_Firm = exitBlockOnFail {
    exec(http("IAPD_HomePage")
    .get(IAPD_url + """/""")
    .headers(headers_0)
    .check(regex("Welcome to the Investment Adviser Public Disclosure website").find.optional.saveAs("HomePageFound"))
      .check(CommonChecks_IAPD: _*))
    .exec(session => if (session.contains("HomePageFound")) session else session.markAsFailed)
    .exitHereIfFailed
    .pause(1, 5)
    .exec(http("IAPD_Searchby_Firm")
    .post(IAPD_url)
    .headers(headers_9)

   /* .formParam( """__LASTFOCUS""", """""")
    .formParam( """__VIEWSTATE""", """${viewstate}""")
    .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
    .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
    .formParam( """ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
    .formParam( """ctl00$cphMain$sbox$rdoSearchBy""", """rdoOrg""")*/

      .formParam("__EVENTTARGET", "")
      .formParam("__EVENTARGUMENT", "")
      .formParam("__VIEWSTATE", """${viewstate}""")
      .formParam("__VIEWSTATEGENERATOR", """${viewstate_generator}""")
      .formParam("__EVENTVALIDATION", """${EventValidation}""")
      .formParam("ctl00$cphMain$sbox$searchScope", "rdoFirm")
      .formParam("ctl00$cphMain$sbox$txtIndvl", "")
      .formParam("ctl00$cphMain$sbox$txtAtFirm", "")
      .formParam("ctl00$cphMain$sbox$txtFirm", "249")
      .formParam("ctl00$cphMain$sbox$ddlZipRange", "5")
      .formParam("ctl00$cphMain$sbox$txtZip", "")
      .formParam("ctl00$cphMain$sbox$searchBtnCheck", "Search")
   // .check(CommonChecks_IAPD: _*)
    .check(regex("Investment Adviser Search").find.optional.saveAs("IASearch"))
    )
   // .exitHereIfFailed

    .exec(doSwitch(session => session("IAPD_frimType").as[String])
    (
      "firm" ->
      exec(http("FirmSrch_ByOrgPK_NoZip")
      .post(IAPD_url )
      .headers(headers_9)
      .formParam( """__EVENTTARGET""", """""")
      .formParam( """__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
/*
      .formParam( """ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
*/
      .formParam( """ctl00$cphMain$sbox$searchScope""", """rdoFirm""")
        .formParam("ctl00$cphMain$sbox$txtIndvl", "")
        .formParam("ctl00$cphMain$sbox$txtAtFirm", "")

        .formParam( """ctl00$cphMain$sbox$txtFirm""", """${FirmNm}""")
      .formParam( """ctl00$cphMain$sbox$txtZip""", """""")
      .formParam( """ctl00$cphMain$sbox$ddlZipRange""", """25""")
        .formParam("ctl00$cphMain$sbox$searchBtnCheck", "Search")
        .check(CommonChecks_IAPD_FirmSearch: _*)

      )
      .pause(1),
      "firmzipradius" ->
      exec(http("FirmSrch_ByOrgPK_Zip")
      .post(IAPD_url)
      .headers(headers_9)
      //.formParam( """__LASTFOCUS""", """""")
      .formParam( """__EVENTTARGET""", """""")
      .formParam( """__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
/*
      .formParam( """ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
*/
      .formParam( """ctl00$cphMain$sbox$searchScope""", """rdoFirm""")
      .formParam( """ctl00$cphMain$sbox$txtFirm""", """${FirmNm}""")
        .formParam("ctl00$cphMain$sbox$txtAtFirm", "")
        .formParam("ctl00$cphMain$sbox$txtIndvl", "")

        .formParam( """ctl00$cphMain$sbox$txtZip""", """${ZipCodeS}""")
      .formParam( """ctl00$cphMain$sbox$ddlZipRange""", """25""")
        .formParam("ctl00$cphMain$sbox$searchBtnCheck", "Search")
              .check(CommonChecks_IAPD_FirmSearch: _*)
      )
      .pause(1),
      "zipradius" ->
      exec(http("FirmSrch_ByOrgPK_Zip")
      .post(IAPD_url)
      .headers(headers_9)
      //.formParam( __LASTFOCUS""", """""")
      .formParam( """__EVENTTARGET""", """""")
      .formParam( """__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
/*
      .formParam( """ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
*/
      .formParam( """ctl00$cphMain$sbox$searchScope""", """rdoFirm""")
      .formParam( """ctl00$cphMain$sbox$txtFirm""", """""")
        .formParam("ctl00$cphMain$sbox$txtAtFirm", "")
        .formParam("ctl00$cphMain$sbox$txtIndvl", "")
      .formParam( """ctl00$cphMain$sbox$txtZip""", """${ZipCodeS}""")
      .formParam( """ctl00$cphMain$sbox$ddlZipRange""", """5""")
        .formParam("ctl00$cphMain$sbox$searchBtnCheck", "Search")
      .check(CommonChecks_IAPD_FirmSearch: _*)
      )
      .pause(1)
    ))
    .pause(1, 5)
    .exec(session => if (!session.contains("NoMatchFound_count")) session else session.markAsFailed)
  //  .exitHereIfFailed
      // find IA org_pk, saved in ViewIAFirmRpt_FirmPk for later click
    .doIf(session => (session.contains("gIA_ORG_PK"))) {
      exec(session => {
        for {
          customers_IA <- session("gIA_ORG_PK").validate[Seq[String]]
          val customer_IA = customers_IA(ThreadLocalRandom.current.nextInt(customers_IA.size))
        } yield session.set("ViewIAFirmRpt_FirmPk", customer_IA)
        //    println("Random IA =" +session("ViewIAFirmRpt_FirmPk").as[String])
        //    session
      }
      )
        //find BD org_pk, saved in customer_BC, for later click
        .doIf(session => (session.contains("gBC_ORG_PK"))) {
          exec(session => {
            for {
              customers_BC <- session("gBC_ORG_PK").validate[Seq[String]]
              val customer_BC = customers_BC(ThreadLocalRandom.current.nextInt(customers_BC.size))
            } yield session.set("customer_BC", customer_BC)})}
        .pause(2)

      // Do if Customer_BC is there




      .pause(1, 5)
      .doIf(session => (session.contains("ViewIAFirmRpt_FirmPk"))) {
        exec(http("IAPD_FirmSrch_ClickIAFirm")
        //.post(IAPD_url + "/IAPD/Content/Search/iapd_landing.aspx?SearchGroup=Firm&FirmKey=${ViewIAFirmRpt_FirmPk}&BrokerKey=-1")
          .get(IAPD_url + "/IAPD/IAPDFirmSummary.aspx?ORG_PK=${ViewIAFirmRpt_FirmPk}")
        .headers(headers_0)
       /* .exec(http("request_19")

            .get(uri4 + "/WebResource.axd?d=1Wt0_mB-mhWVZvNxnVmWf2VW6UaFE35bZSDHneDYcSXAGG8CWnx89lBLJrDj_wqRENUGcKoj3nX4Id51BwtB2SFHFEnwnJgT1U-aAeIAZ6-6N_SsCY0280kGT9YDYP37PBFfLAfl7JFqAPgF8EYmaKWVTqdV8Q8QQGSGOcInLX81&t=635866712280000000")
            .headers(headers_10),

            http("request_25")
              .get(uri4 + "/IAPD/fonts/fontawesome-webfont.ttf?v=3.2.1")
              .headers(headers_10)
          )*/
        .check(regex( """RGLTR_PK=(\d+)"""").find.optional.saveAs("gRGLTR_PK"))
        .check(regex( """crd_iapd_AdvVersionSelector.aspx?ORG_PK=${ViewIAFirmRpt_FirmPk}&""").find.optional.saveAs("Registry_count"))
        .check(regex( """View last Form ADV filed""").find.optional.saveAs("gLastFormAdvFiled_count")))
         /* .exec(http("request_19")

            .get(uri4 + "/WebResource.axd?d=1Wt0_mB-mhWVZvNxnVmWf2VW6UaFE35bZSDHneDYcSXAGG8CWnx89lBLJrDj_wqRENUGcKoj3nX4Id51BwtB2SFHFEnwnJgT1U-aAeIAZ6-6N_SsCY0280kGT9YDYP37PBFfLAfl7JFqAPgF8EYmaKWVTqdV8Q8QQGSGOcInLX81&t=635866712280000000")
            .headers(headers_10)
          )
          .exec(
            http("request_25")
              .get(uri4 + "/IAPD/fonts/fontawesome-webfont.ttf?v=3.2.1")
              .headers(headers_10)
          )*/
          .doIf(session =>(session.contains("""ADV_PDF"""))){
            exec(http("Click on View Latest Form ADV filed PDF")
              .get(IAPD_url + "/IAPD/content/ViewForm/crd_iapd_stream_pdf.aspx?ORG_PK=${ViewIAFirmRpt_FirmPk}")
              .headers(headers_0)
            )
          }
          .doIf(session => (session.contains("""nbc_firm"""))){
            exec(http("Click on nbc site")
            .get("http://fbc-int.dev.finra.org/Support/BC_Summary_Link.aspx?IndividualID=-1&Source=Summary&FirmID=${ViewIAFirmRpt_FirmPk}")
            .headers(Map("""Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""","""Accept-Encoding""" -> """gzip, deflate""","""Cache-Control""" -> """max-age=0""",
              """Origin""" -> "fbc-int.dev.finra.org"))
            )
          }
          .doIfOrElse(session => session.contains("gLastFormAdvFiled_count")) {
          exec(http("IAPD_FirmSrch_ADVPart1A_Item1_IDInfo")
          .get(IAPD_url + "/IAPD/crd_iapd_AdvVersionSelector.aspx?ORG_PK=${ViewIAFirmRpt_FirmPk}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"""))
          .check(regex( """FLNG_PK=(.*?)"""").find.optional.saveAs("gFLNG_PK"))
          .check(regex( """STATE_CD=(.*?)&""").find.optional.saveAs("gSTATE_CD"))
          .check(regex( """iapd_AdvIdentifyingInfoSection.aspx?(.*?)"""").find.optional.saveAs("FullredirectLink"))
          .check(css( """a.Nav""", "href").findAll.optional.saveAs("gADV_LINKS"))
          .check(currentLocation.optional.saveAs("Redirect_REQUEST_URI"))
          .check(currentLocationRegex("http://iapd-stress.finra.org/iapd/content/viewform/(.*)/sections/").ofType[String].find.optional.saveAs("gFORM_VERSION")))
        } {
          doIf(session => session.contains("gRGLTR_PK")) {
            exec(http("IAPD_FirmSrch_ADVPart1A_Item1_IDInfo")
            .get(IAPD_url + "/IAPD/crd_iapd_AdvVersionSelector.aspx?ORG_PK=${ViewIAFirmRpt_FirmPk}&RGLTR_PK=${gRGLTR_PK}")
            .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"""))
            .check(regex( """FLNG_PK=(.*?)"""").find.optional.saveAs("gFLNG_PK"))
            .check(regex( """STATE_CD=(.*?)&""").find.optional.saveAs("gSTATE_CD"))
            //.check(regex( """iapd/content/viewform/(.*?)/""").find.optional.saveAs("gFORM_VERSION"))
            .check(regex( """iapd_AdvIdentifyingInfoSection.aspx?(.*?)"""").find.optional.saveAs("FullredirectLink"))
            .check(css( """a.Nav""", "href").findAll.optional.saveAs("gADV_LINKS"))
            .check(currentLocation.optional.saveAs("Redirect_REQUEST_URI"))
            .check(currentLocationRegex("http://iapd-stress.finra.org/iapd/content/viewform/(.*)/sections/").ofType[String].find.optional.saveAs("gFORM_VERSION"))
            )
          }
        }
      }
    }


  }


  // get the random value from the list for IA
  val IAPD_FirmSearch_GetLinks = doIf(session => (session.contains("gIA_ORG_PK"))) {
    exec(session => { for {customers_IA <- session("gIA_ORG_PK").validate[Seq[String]]
                           val customer_IA = customers_IA(ThreadLocalRandom.current.nextInt(customers_IA.size))
    } yield session.set("ViewIAFirmRpt_FirmPk", customer_IA)   }    )
  }
  /*Investment Adviser Search Results
      Click IA Firm*/
  val ViewIAFirmRpt = group("ViewIAFirmRpt") {
    doIf(session => (session.contains("ViewIAFirmRpt_FirmPk"))) {
      exec(http("IAPD_FirmSrch_ClickIAFirm2")
        .get(IAPD_url + "/IAPD/IAPDFirmSummary.aspx?ORG_PK=${ViewIAFirmRpt_FirmPk}")
        .headers(headers_0)
        .check(regex( """FLNG_PK=(.*?)&#xA""").find.optional.saveAs("gFLNG_PK"))
        .check(regex( """RGLTR_PK=(\d+)"""").find.optional.saveAs("gRGLTR_PK"))
        .check(regex( """crd_iapd_AdvVersionSelector.aspx?ORG_PK=${ViewIAFirmRpt_FirmPk}&""").find.optional.saveAs("Registry_count"))
        .check(regex( """View last Form ADV filed""").find.optional.saveAs("gLastFormAdvFiled_count"))
      )
        .exec(http("IAPD_FirmSrch_ADVPart1A_Item1_IDInfo")
            .get(IAPD_url+"/IAPD/crd_iapd_AdvVersionSelector.aspx?ORG_PK=${ViewIAFirmRpt_FirmPk}")
            .headers(headers_0)
            .check(regex( """FLNG_PK=(.*?)&#xA""").find.optional.saveAs("gFLNG_PK"))
            .check(regex( """STATE_CD=(.*?)&""").find.optional.saveAs("gSTATE_CD"))
            .check(regex( """iapd_AdvIdentifyingInfoSection.aspx?(.*?)"""").find.optional.saveAs("FullredirectLink"))
            .check(css( """a.Nav""", "href").findAll.optional.saveAs("gADV_LINKS"))
            //.check(currentLocation.optional.saveAs("Redirect_REQUEST_URI"))
            //.check(currentLocationRegex("http://iapd-stress.finra.org/iapd/content/viewform/(.*)/sections/").ofType[String].find.optional.saveAs("gFORM_VERSION"))
          )
        /*}*//*{doIf(session => session.contains("gRGLTR_PK")) {
          exec(http("IAPD_FirmSrch_ADVPart1A_Item1_IDInfo")
            .get(IAPD_url+"/IAPD/crd_iapd_AdvVersionSelector.aspx?ORG_PK=${ViewIAFirmRpt_FirmPk}&RGLTR_PK=${gRGLTR_PK}")
            .headers(header_9)
            .check(regex( """FLNG_PK=(.*?)"""").find.optional.saveAs("gFLNG_PK"))
            .check(regex( """STATE_CD=(.*?)&""").find.optional.saveAs("gSTATE_CD"))
            //.check(regex( """iapd/content/viewform/(.*?)/""").find.optional.saveAs("gFORM_VERSION"))
            .check(regex( """iapd_AdvIdentifyingInfoSection.aspx?(.*?)"""").find.optional.saveAs("FullredirectLink"))
            .check(css( """a.Nav""", "href").findAll.optional.saveAs("gADV_LINKS"))
            .check(currentLocation.optional.saveAs("Redirect_REQUEST_URI"))
            .check(currentLocationRegex("http://iapd-stress.finra.org/iapd/content/viewform/(.*)/sections/").ofType[String].find.optional.saveAs("gFORM_VERSION"))
          )
        }}*/


/*
                .exec(doSwitch(session => session("ViewSection").as[String])
                (*/
      .doIf(session => (session.contains("gFLNG_PK"))) {
        //Item 3 Form of Organization
        //"iapd_AdvFormOfOrgSection.aspx" ->
        exec(http("IAPD_FirmSrch_ADVPart1A_Item3_FormOfOrg")
          .get(IAPD_url + "/IAPD/content/viewform/adv/Sections/iapd_AdvFormOfOrgSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")
          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex("Form of Organization Section").find.optional.saveAs("Form_of_Organization_Section")))
          .pause(5)
          // "iapd_AdvSuccessionsSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADVPart1A_Item4_Successions")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvSuccessionsSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Successions Section""").find.optional.saveAs("Successions")))
          .pause(5)
        // "iapd_AdvAdvisoryBusinessSection.aspx" ->
        exec(http("IAPD_FirmSrch_ADVPart1A_Item5_AdvisoryBusines")
          .get(IAPD_url + "/iapd/content/viewform/${gFORM_VERSION}/Sections/iapd_AdvAdvisoryBusinessSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")
          .queryParam("RGLTR_PK", "${gRGLTR_PK}")
          .queryParam("STATE_CD", "${gSTATE_CD}")
          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Information About Your Advisory Business Section""").find.optional.saveAs("Advisory_Section")))
          .pause(5)
          // "iapd_AdvOtherBusinessSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADVPart1A_Item6_OtherBusiness")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvOtherBusinessSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Other Business Section""").find.optional.saveAs("OtherBusiness_Section")))
          .pause(5)
          //"iapd_AdvFinancialAffiliationsSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADVPart1A_Item7_AffilAndPrivateFunds")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvFinancialAffiliationsSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Financial Industry Affiliations""").find.optional.saveAs("Financial_Industry_Affiliations_Section")))
          .pause(5)
          //"iapd_AdvClientTransSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADVPart1A_Item8_ClientTransactions")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvClientTransSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Client Transactions Section""").find.optional.saveAs("ClientTransactions_Section")))
          .pause(5)
          //"iapd_AdvCustodySection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADVPart1A_Item9_Custody")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvCustodySection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Custody Section""").find.optional.saveAs("Custody_Section")))
          .pause(5)
          //"iapd_AdvControlPersonsSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADVPart1A_Item10_ControlPersons")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvControlPersonsSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Control Persons Section""").find.optional.saveAs("ControlPersons_Section")))
          .pause(5)
          //"iapd_AdvDisciplinarySection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADVPart1A_Item11_DisclosureInfo")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvDisciplinarySection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Disciplinary Section""").find.optional.saveAs("Disciplinary_Section")))
          .pause(5)
        //"iapd_AdvSmallBusinessSection.aspx" ->
        exec(http("IAPD_FirmSrch_ADVPart1A_Item12_SmallBusiness")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvSmallBusinessSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Small Businesses Section""").find.optional.saveAs("SmallBusiness_Section")))
          .pause(5)
          //"iapd_Adv1BStateRegSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADVPart2_Item1_StateReg")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_Adv1BStateRegSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Form ADV Part 1B, State Registration Section""").find.optional.saveAs("FormADVPart1BStateRegistration_Section")))
          .pause(5)
          //"iapd_Adv1BAdditionalInfoSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADVPart2_Item2_AdditionalInfo")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_Adv1BAdditionalInfoSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Form ADV Part 1B, Additional Information Section""").find.optional.saveAs("FormADVPart1BStateAdditional_Section")))
          .pause(5)
          //"iapd_AdvDisciplinary1BSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADVPart1B_Item2_AdditonalInfo")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvDisciplinary1BSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Form ADV Part 1B, Additional Information Section""").find.optional.saveAs("FormADVPart1BStateAdditional_Section")))
          .pause(5)
          //"iapd_AdvDisciplinaryDrpSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADV_DRPs")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvDisciplinaryDrpSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """DRPs""").find.optional.saveAs("DRPSection")))
          .pause(5)
          //"iapd_AdvRegulatorStatusSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADV_RegReportingStatus")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvDisciplinaryDrpSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Registration/Reporting Status""").find.optional.saveAs("RegistrationReporting_Section")))
          .pause(5)
          //"iapd_Adv2Brochures.aspx" ->
          .exec(http("IAPD_FirmSrch_ADV_Part2_Brochures")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_Adv2Brochures.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Part 2""").find.optional.saveAs("Part2_Section")))
          .pause(5)
          //"iapd_AdvScheduleASection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADV_ScheduleA")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvScheduleASection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Schedule A""").find.optional.saveAs("ScheduleA_Section")))
          .pause(5)
          //"iapd_AdvScheduleBSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADV_ScheduleB")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvScheduleBSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Schedule B""").find.optional.saveAs("ScheduleB_Section")))
          .pause(5)
          //"iapd_AdvScheduleDSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADV_ScheduleD")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvScheduleDSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Schedule D""").find.optional.saveAs("ScheduleD_Section")))
          .pause(5)
          //"iapd_AdvSignatureSection.aspx" ->
          .exec(http("IAPD_FirmSrch_ADV_SignaturePage")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvSignatureSection.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """Signature Section""").find.optional.saveAs("Signature_Section")))
          .pause(5)
          //"iapd_adveSurpriseExamRpt.aspx" ->
          .exec(http("IAPD_FirmSrch_ADV_SupriseExamRpt")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_adveSurpriseExamRpt.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """FORM ADV-E""").find.optional.saveAs("FORM_ADV-E_Section")))
          .pause(5)
          //"iapd_AdvAllPages.aspx" ->
          .exec(http("IAPD_FirmSrch_ADV_ViewAllPages")
          .get(IAPD_url + "/iapd/content/viewform/adv/Sections/iapd_AdvAllPages.aspx")
          .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")

          .queryParam("FLNG_PK", "${gFLNG_PK}")
          .queryParam("Print", "Y")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Cache-Control""" -> """max-age=0"""))
          .check(regex( """IAPD - View All""").find.optional.saveAs("IAPD_ViewAllPages"))
          .check(responseTimeInMillis.saveAs("responseTimeInMillis_ViewAllPages")))
          .pause(5)
        //  ) // switch complete
        // completing doswitch
      }

            }
/*            .foreach("${links_gADV}", "gADVLink") {
              exec { session =>
                // println("Section =  " + (session("gADVLink").as[String]))
                val StreamPDFSection = returnSectionStreamPDF(session("gADVLink").as[String])
                //  println("StreamPDF Section Section = " + StreamPDFSection)
                session.set("StreamPDFSection", StreamPDFSection)
              }
                .doIf(session => session("StreamPDFSection").as[String] == "crd_iapd_stream_pdf.aspx") {
                  exec(http("IAPD_FirmSrch_ADV_ViewAllPages_Stream_PDF")
                    .get(IAPD_url+"/IAPD/Content/ViewForm/crd_iapd_stream_pdf.aspx")
                    .queryParam("ORG_PK", "${ViewIAFirmRpt_FirmPk}")
                    .queryParam("RGLTR_PK", "${gRGLTR_PK}")
                    .queryParam("STATE_CD", "${gSTATE_CD}")
                    .queryParam("FLNG_PK", "${gFLNG_PK}")
                    .queryParam("Print", "Y")
                    .headers(header_9)
                    //  .check(bodyString.saveAs("sizeofpdf"))
                    .check(regex( """IAPD - View All""").find.optional.saveAs("IAPD_ViewAllPages"))
                    .check(responseTimeInMillis.saveAs("responseTimeInMillis_ViewAllPages")))
                    .pause(5)
                  //                  .exec {session =>
                  //                  println("*********************")
                  //                  println( "ORG_PK -  " + session("ViewIAFirmRpt_FirmPk").as[String] +"   size of pdf -  " + session("sizeofpdf").as[String].size + "  (Bytes) ")
                  //                  println( "ORG_PK -  " + session("ViewIAFirmRpt_FirmPk").as[String] +"   size of pdf -  " + ReadablizeBytes(session("sizeofpdf").as[String].size))
                  //                  println("*********************")
                  //                  session}
                }
            }*/
        }
  //<h1 class="page-header">Welcome to Investment Adviser Disclosure website</h1>

  private val search_IAPD_Indvlonly = exitBlockOnFail {
    exec(http("IAPD_HomePage")
    .get(IAPD_url + """/""")
    .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"""))
    .check(regex("Welcome to the Investment Adviser Public Disclosure website").find.optional.saveAs("HomePageFound"))
    .check(CommonChecks_IAPD: _*)
    )
    .exec(session => if (session.contains("HomePageFound")) session else session.markAsFailed)
    .exitHereIfFailed
    .pause(1,3)
    .exitHereIfFailed
    .exec(http("InvdlSrch_ByNameOnly")
    .post(IAPD_url + "/")
    .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Accept-Encoding""" -> """gzip, deflate""", """Cache-Control""" -> """max-age=0""", """Origin""" -> IAPD_url))
    //.formParam( """__LASTFOCUS""", """""")
    .formParam( """__EVENTTARGET""", """""")
    .formParam( """__EVENTARGUMENT""", """""")
    .formParam( """__VIEWSTATE""", """${viewstate}""")
    .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
    .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
    //.formParam( """ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
    .formParam( """ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
    .formParam( """ctl00$cphMain$sbox$txtIndvl""", """patel""")
    .formParam( """ctl00$cphMain$sbox$txtAtFirm""", """""")
    .formParam( """ctl00$cphMain$sbox$txtFirm""", """""")
    .formParam( """ctl00$cphMain$sbox$ddlZipRange""", """25""")
      .formParam( """ctl00$cphMain$sbox$txtZip""", """20850""")
    .formParam( """ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
    )

      .doIf(session => session.contains("IAPD_IDLists")) {
        exec(session => {
          for {iNDPK_Values <- session("IAPD_IDLists").validate[Seq[String]]
               val rnd_value = iNDPK_Values(ThreadLocalRandom.current.nextInt(iNDPK_Values.size))}
            yield session.set("rndIAPD_IndvId", rnd_value)
        })
          .exec(http("Indvl_summaryPage")
            .get(IAPD_url + """/IAPD/IAPDIndvlSummary.aspx?""")
            .queryParam("INDVL_PK","${rndIAPD_IndvId}"))
          .pause(1,4)
          .exec(http("report")
            .get(IAPD_url+"/IAPD/Support/ReportStatus.aspx?")
            .queryParam("indvl_pk","${rndIAPD_IndvId}"))
      }


  }
  private val pagination_indvl_search = exitBlockOnFail{
    exec(http("IAPD_HomePage")
      .get(IAPD_url + """/""")
      .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"""))
      .check(regex("Welcome to the Investment Adviser Public Disclosure website").find.optional.saveAs("HomePageFound"))
      .check(CommonChecks_IAPD: _*)
      .check(regex("Next").find.optional.saveAs("next"))
    )
      .exec(session => if (session.contains("HomePageFound")) session else session.markAsFailed)
      .exitHereIfFailed
      .pause(1,3)
      .exitHereIfFailed
      .asLongAs(session => session.contains("next")) {
        exec(http("InvdlSrch_ByNameOnly")
          .post(IAPD_url + "/")
          .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Accept-Encoding""" -> """gzip, deflate""", """Cache-Control""" -> """max-age=0""", """Origin""" -> IAPD_url))
          //.formParam( """__LASTFOCUS""", """""")
          .formParam( """__EVENTTARGET""", """ctl00$cphMain$ucSearchPagerBottom$pageNext""")
          .formParam( """__EVENTARGUMENT""", """""")
          .formParam( """__VIEWSTATE""", """${viewstate}""")
          .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
          .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
          .formParam( """ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
          .formParam( """ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
          .formParam( """ctl00$cphMain$sbox$txtIndvl""", """${Searchterm}""")
          .formParam( """ctl00$cphMain$sbox$txtAtFirm""", """""")
          .formParam( """ctl00$cphMain$sbox$txtFirm""", """""")
          .formParam( """ctl00$cphMain$sbox$ddlZipRange""", """25""")
          .formParam( """ctl00$cphMain$sbox$txtZip""", """""")
          .formParam( """ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
          .check(CommonChecks_IAPD_IndvlSearch: _*)
          .check(regex("Next").find.optional.saveAs("next"))
        )
      }


  }

  private val IAPD_HomePage = exitBlockOnFail {
    exec(http("IAPD_HomePage")
    .get(IAPD_url + """/""")
    .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"""))
      .check(CommonChecks_IAPD: _*)
    .check(regex("Welcome to the Investment Adviser Public Disclosure website").find.optional.saveAs("HomePageFound")))
    .exec(session => if (session.contains("HomePageFound")) session else session.markAsFailed)
    .exitHereIfFailed
  }

  private val IAPD_SelectIndvlSearch = exitBlockOnFail {
    exec(http("IAPD_SearchPage")
    .get(IAPD_url)
    .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"""))
    .check(regex("Investment Adviser Search").find.optional.saveAs("IASearch"))
    .check(CommonChecks_IAPD: _*))
    .exitHereIfFailed
    .pause(1, 5)
    .exec(http("IAPD_Searchby_Indvl")
    .post(IAPD_url + """/""")
    .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Accept-Encoding""" -> """gzip, deflate""", """Cache-Control""" -> """max-age=0""", """Origin""" -> IAPD_url))
      .formParam( """__LASTFOCUS""", """""")
      .formParam( """__EVENTTARGET""", """""")
      .formParam( """__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      //.formParam( """ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam( """ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam( """ctl00$cphMain$sbox$txtIndvl""", """""")
      .formParam( """ctl00$cphMain$sbox$txtAtFirm""", """""")
      .formParam( """ctl00$cphMain$sbox$txtFirm""", """""")
      .formParam( """ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam( """ctl00$cphMain$sbox$txtZip""", """""")
      .formParam( """ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
    .check(CommonChecks_IAPD: _*)
    .check(regex("Investment Adviser Search").find.optional.saveAs("IASearch")))
    .pause(1, 3)
    .exitHereIfFailed
  }

  //  INDVL_PK;LAST_NM;FIRST_NM;MID_NM;DSPLY_NM;ORG_PK;IA_SEC_NB;BC_LEGAL_NM;IA_LEGAL_NM;BD_SEC_NB;POSTL_CD;SearchDataType

  private val IAPD_IndvlSearch_multipleparameter =
    feed(feeder_Indvdata)
    .exec(doSwitch(session => session("Searchby").as[String])
    (
      "indvlpk" ->
      exec(http("Searchby_IndvlPK")
      .post(IAPD_url)
      .headers(header_IapdInvlsearch)
      //.formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      //.formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """${INDVL_PK}""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """""")
        .formParam("""ctl00$cphMain$sbox$txtAtFirm""", """""")

        .formParam("""ctl00$cphMain$sbox$txtZip""", """""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1),
      "randomtext" ->
      exec(http("Searchby_Indvltext")
      .post(IAPD_url+"""/""")
      .headers(header_IapdInvlsearch)
      //.formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
     // .formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """${SearchText}""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """""")
        .formParam("""ctl00$cphMain$sbox$txtAtFirm""", """""")

        .formParam("""ctl00$cphMain$sbox$txtZip""", """""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1)
      ,
      "indvlname" ->
      exec(http("Searchby_Indvlname")
      .post(IAPD_url+"""/""")
      .headers(header_IapdInvlsearch)
     // .formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      //.formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """${LAST_NM}""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """""")
        .formParam("""ctl00$cphMain$sbox$txtAtFirm""", """""")

        .formParam("""ctl00$cphMain$sbox$txtZip""", """""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1)
      ,
      "indvlnamefirmname" ->
      exec(http("Searchby_Indvlnamefirmname")
      .post(IAPD_url+"""/""")
      .headers(header_IapdInvlsearch)
     // .formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
     // .formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """${LAST_NM}""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """${IA_LEGAL_NM}""")
        .formParam("""ctl00$cphMain$sbox$txtAtFirm""", """""")

      .formParam("""ctl00$cphMain$sbox$txtZip""", """""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1)
      ,
      "indvlnamefirmpk" ->
      exec(http("Searchby_IndvlnameFirmPK")
      .post(IAPD_url+"""/""")
      .headers(header_IapdInvlsearch)
     // .formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      //.formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """${LAST_NM}""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """${ORG_PK}""")
        .formParam("""ctl00$cphMain$sbox$txtAtFirm""", """""")

        .formParam("""ctl00$cphMain$sbox$txtZip""", """""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1)
      ,
      "indvlnamefirmbdsecnum" ->
      exec(http("Searchby_IndvlnamefirmBDSecNum")
      .post(IAPD_url+"""/""")
      .headers(header_IapdInvlsearch)
     // .formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
     // .formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
        .formParam("""ctl00$cphMain$sbox$txtAtFirm""", """""")

      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """${LAST_NM}""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """${BD_SEC_NB}""")
      .formParam("""ctl00$cphMain$sbox$txtZip""", """""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1)
      ,
      "indvlnamefirmIASecnum" ->
      exec(http("Searchby_IndvlnamefirmIASecNum")
      .post(IAPD_url+"""/""")
      .headers(header_IapdInvlsearch)
     // .formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
        .formParam("""ctl00$cphMain$sbox$txtAtFirm""", """""")

        .formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """${LAST_NM}""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """${IA_SEC_NB}""")
      .formParam("""ctl00$cphMain$sbox$txtZip""", """""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1)
      ,
      "indvlnamewithzip" ->
      exec(http("Searchby_IndvlnameZip")
      .post(IAPD_url+"""/""")
      .headers(header_IapdInvlsearch)
      //.formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      .formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """${LAST_NM}""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """""")
      .formParam("""ctl00$cphMain$sbox$txtZip""", """${POSTL_CD}""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1)
      ,
      "zipsearchonly" ->
      exec(http("Searchby_Zip")
      .post(IAPD_url+"""/""")
      .headers(header_IapdInvlsearch)
     // .formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      .formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """""")
      .formParam("""ctl00$cphMain$sbox$txtZip""", """${POSTL_CD}""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1)
      ,
      "bcfirmnamezip" ->
      exec(http("Searchby_firmnameZip")
      .post(IAPD_url+"""/""")
      .headers(header_IapdInvlsearch)
     // .formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      .formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """{BC_LEGAL_NM}""")
      .formParam("""ctl00$cphMain$sbox$txtZip""", """${POSTL_CD}""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1)
      ,
      "iafirmnamezip" ->
      exec(http("Searchby_FirmIAnameZip")
      .post(IAPD_url+"""/""")
      .headers(header_IapdInvlsearch)
     // .formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      .formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """{IA_LEGAL_NM}""")
      .formParam("""ctl00$cphMain$sbox$txtZip""", """${POSTL_CD}""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1),
      "bdsecnumzip" ->
      exec(http("Searchby_FirmBDSecNumZip")
      .post(IAPD_url+"""/""")
      .headers(header_IapdInvlsearch)
     // .formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      .formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """{BD_SEC_NB}""")
      .formParam("""ctl00$cphMain$sbox$txtZip""", """${POSTL_CD}""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1)
      ,
      "iasecnumzip" ->
      exec(http("Searchby_FirmIASecNumZip")
      .post(IAPD_url+"""/""")
      .headers(header_IapdInvlsearch)
   //   .formParam("""__LASTFOCUS""", """""")
      .formParam("""__EVENTTARGET""", """""")
      .formParam("""__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      .formParam("""ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam("""ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam("""ctl00$cphMain$sbox$txtIndvl""", """""")
      .formParam("""ctl00$cphMain$sbox$txtFirm""", """{IA_SEC_NB}""")
      .formParam("""ctl00$cphMain$sbox$txtZip""", """${POSTL_CD}""")
      .formParam("""ctl00$cphMain$sbox$ddlZipRange""", """5""")
      .formParam("""ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      )
      .pause(1)
    ))








  /* MAIN Search and view report for the IAPD - INDIVIDUAL */

  private val search_IAPD_Indvl = exitBlockOnFail {
    exec(http("IAPD_HomePage")
    .get(IAPD_url + """/""")
    .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"""))
    .check(regex("Welcome to the Investment Adviser Public Disclosure website").find.optional.saveAs("HomePageFound"))
      .check(CommonChecks_IAPD: _*)
    )
    .exec(session => if (session.contains("HomePageFound")) session else session.markAsFailed)
    .exitHereIfFailed
    .pause(1)
    .exec(http("IAPD_Searchby_Indvl")
    .post(IAPD_url )
      .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Accept-Encoding""" -> """gzip, deflate""", """Cache-Control""" -> """max-age=0""", """Origin""" -> IAPD_url))
      .formParam( """__LASTFOCUS""", """""")
      .formParam( """__EVENTTARGET""", """""")
      .formParam( """__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      //.formParam( """ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam( """ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam( """ctl00$cphMain$sbox$txtIndvl""", """""")
     // .formParam( """ctl00$cphMain$sbox$txtAtFirm""", """""")
      .formParam( """ctl00$cphMain$sbox$txtFirm""", """""")
      .formParam( """ctl00$cphMain$sbox$ddlZipRange""", """25""")
      .formParam( """ctl00$cphMain$sbox$txtZip""", """10013""")
      .formParam( """ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
   // .check(CommonChecks_IAPD: _*)
    .check(regex("Investment Adviser Search").find.optional.saveAs("IASearch")))
    .exitHereIfFailed

    .exec(doSwitch(session => session("IAPD_IND_searchtype").as[String])
    (
      "name" ->
      exec(http("InvdlSrch_ByName")
      .post(IAPD_url )
      .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Accept-Encoding""" -> """gzip, deflate""", """Cache-Control""" -> """max-age=0""", """Origin""" -> IAPD_url))
    //  .formParam( """__LASTFOCUS""", """""")
      .formParam( """__EVENTTARGET""", """""")
      .formParam( """__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
    //  .formParam( """ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam( """ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam( """ctl00$cphMain$sbox$txtIndvl""", """${Searchterm}""")
      .formParam( """ctl00$cphMain$sbox$txtFirm""", """""")
      .formParam( """ctl00$cphMain$sbox$txtZip""", """""")
      .formParam( """ctl00$cphMain$sbox$ddlZipRange""", """${Radius}""")
      .formParam( """ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      ).pause(1),
      "zip" ->
      exec(http("InvdlSrch_ByZip")
      .post(IAPD_url )
      .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Accept-Encoding""" -> """gzip, deflate""", """Cache-Control""" -> """max-age=0""", """Origin""" -> IAPD_url))
      .formParam( """__LASTFOCUS""", """""")
      .formParam( """__EVENTTARGET""", """""")
      .formParam( """__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      //.formParam( """ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam( """ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam( """ctl00$cphMain$sbox$txtIndvl""", """""")
      .formParam( """ctl00$cphMain$sbox$txtFirm""", """""")
      .formParam( """ctl00$cphMain$sbox$txtZip""", """${ZipCode}""")
      .formParam( """ctl00$cphMain$sbox$ddlZipRange""", """${Radius}""")
      .formParam( """ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      ).pause(1),
      "namezip" ->
      exec(http("InvdlSrch_ByName")
      .post(IAPD_url )
      .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Accept-Encoding""" -> """gzip, deflate""", """Cache-Control""" -> """max-age=0""", """Origin""" -> IAPD_url))
     // .formParam( """__LASTFOCUS""", """""")
      .formParam( """__EVENTTARGET""", """""")
      .formParam( """__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
     // .formParam( """ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam( """ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam( """ctl00$cphMain$sbox$txtIndvl""", """${Searchterm}""")
      .formParam( """ctl00$cphMain$sbox$txtFirm""", """""")
      .formParam( """ctl00$cphMain$sbox$txtZip""", """${ZipCode}""")
      .formParam( """ctl00$cphMain$sbox$ddlZipRange""", """${Radius}""")
      .formParam( """ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      ).pause(1),
      "orgzip" ->
      exec(http("InvdlSrch_ByOrgZip")
      .post(IAPD_url )
      .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Accept-Encoding""" -> """gzip, deflate""", """Cache-Control""" -> """max-age=0""", """Origin""" -> IAPD_url))
     // .formParam( """__LASTFOCUS""", """""")
      .formParam( """__EVENTTARGET""", """""")
      .formParam( """__EVENTARGUMENT""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
    //  .formParam( """ctl00$cphMain$sbox$txtChallegePhrase""", """Str3ss@finra.org""")
      .formParam( """ctl00$cphMain$sbox$searchScope""", """rdoIndvl""")
      .formParam( """ctl00$cphMain$sbox$txtIndvl""", """""")
      .formParam( """ctl00$cphMain$sbox$txtFirm""", """${orgnum}""")
      .formParam( """ctl00$cphMain$sbox$txtZip""", """${ZipCode}""")
      .formParam( """ctl00$cphMain$sbox$ddlZipRange""", """${Radius}""")
      .formParam( """ctl00$cphMain$sbox$searchBtnCheck""", """Search""")
      .check(CommonChecks_IAPD_IndvlSearch: _*)
      .check(CommonChecks_IAPD: _*)
      ).pause(1)
    ))
    .pause(1)
      .doIf(session => session.contains("IAPD_IDLists")) {
        exec(session => {
          for {iNDPK_Values <- session("IAPD_IDLists").validate[Seq[String]]
               val rnd_value = iNDPK_Values(ThreadLocalRandom.current.nextInt(iNDPK_Values.size))}
            yield session.set("rndIAPD_IndvId", rnd_value)
        })
          .exec(http("Indvl_summaryPage")
            .get(IAPD_url + """/IAPD/IAPDIndvlSummary.aspx?""")
            .queryParam("INDVL_PK","${rndIAPD_IndvId}"))
          .pause(1,4)
          .exec(http("report")
            .get(IAPD_url+"/IAPD/Support/ReportStatus.aspx?")
            .queryParam("indvl_pk","${rndIAPD_IndvId}"))
      }
    /*.doIf(session => (session.contains("ViewIAIndvlRpt_ctrlLink"))) {
      exec(http("IAPD_IndvlSrch_Summary_ClickIAFirm")
      .post(IAPD_url + "/IAPD/Content/Search/iapd_indvlSearch_Results.aspx?SearchGroup=Individual&IndlText=${Searchterm}&FirmText=${orgnum}&ZipCode=${ZipCode}&ZipRadius=${Radius}&PageNumber=1")
      .formParam( """__EVENTTARGET""", """${ViewIAIndvlRpt_ctrlLink}""")
      .formParam( """__EVENTARGUMENT""", """""")
      .formParam( """__LASTFOCUS""", """""")
      .formParam( """__VIEWSTATE""", """${viewstate}""")
      .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
      .formParam( """__EVENTVALIDATION""", """${EventValidation}""")
      .formParam( """ctl00$cphMainContent$grResults$ctl01$ddlPageSize""", """25""")
      .formParam( """ctl00$cphMainContent$grResults$ctl29$ddlPageSize""", """25""")
      .check(regex( """Indvl_PK=(\d+)"""").find.optional.saveAs("Dynamic_Indvl_PK"))
      )
    }
    .doIf(session => ThreadLocalRandom.current.nextInt(10) > 8) {
      doIf(session => (session.contains("Dynamic_Indvl_PK"))) {
        exec(http("IAPD_IndvlSrch_IAPD_Detailed_Rpt")
        .get(IAPD_url + """/IAPD/Support/ReportStatus.aspx?indvl_pk=${Dynamic_Indvl_PK}""")
        .check(regex( """__VIEWSTATE" value="(.*)"""").find.optional.saveAs("viewstate"))
        .check(regex( """__VIEWSTATEGENERATOR" value="(.*)"""").find.optional.saveAs("viewstate_generator"))
        )
        .asLongAs(session => !session.contains("EndofPdf")) {
          exec(http("IAPD_IndvlSrch_IAPD_Detailed_ReportStatus_Finish")
          .post(IAPD_url + """/IAPD/Support/ReportStatus.aspx?indvl_pk=${Dynamic_Indvl_PK}""")
          .check(regex( """__VIEWSTATE" value="(.*)"""").find.optional.saveAs("viewstate"))
          .check(regex( """__VIEWSTATEGENERATOR" value="(.*)"""").find.optional.saveAs("viewstate_generator"))
          .headers(header_9)
          .formParam( """__EVENTTARGET""", """""")
          .formParam( """__EVENTARGUMENT""", """""")
          .formParam( """__VIEWSTATE""", """${viewstate}""")
          .formParam( """__VIEWSTATEGENERATOR""", """${viewstate_generator}""")
          .formParam( """__CALLBACKID""", """__Page""")
          .formParam( """__CALLBACKPARAM""", """Processing,1,-1,-1,-1""")
          .resources(http("IAPD_IndvlSrch_IAPD_Detailed_ReportViewer")
          .get(IAPD_url + """/IAPD/Support/ReportViewer.aspx?indvl_pk=${Dynamic_Indvl_PK}""")
          .check(regex("trailer").find.optional.saveAs("EndofPdf"))
          )
          )
        }
      }
    }*/
    .doIf(session => (session.contains("gIAIndvl_Ctrl_BC"))) {
      exec(session => {
        for {
          bccustomers_Indvl <- session("gIAIndvl_Ctrl_BC").validate[Seq[String]]
          val bc_Indvl_IA = bccustomers_Indvl(ThreadLocalRandom.current.nextInt(bccustomers_Indvl.size))
        } yield session.set("viewIAIndvlRpt_BCLink", bc_Indvl_IA)
        //     println("Random BC individual =" +session("viewIAIndvlRpt_BCLink").as[String])
        //      session
      }
      )
      .exec(http("IAPD_IndvlSrch_In_BC_Summary_Link")
      .get(BC_url + """/Support/BC_Summary_Link.aspx""")
      .queryParam("IndividualID", "${viewIAIndvlRpt_BCLink}")
      .queryParam("Source", "Summary")
      .check(currentLocation.optional.saveAs("Redirect_REQUEST_URI_IAPD"))
      .check(regex( """Please enter a correct password""").findAll.optional.saveAs("RedirectHomePage"))
      .check(css("input[name=__RequestVerificationToken", "value").find.optional.saveAs("Token"))
      .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"""))
      .check(regex( """/Report/View/(.*?)/1""").find.optional.saveAs("Indvl_DetailReport"))
      )
    }
    .pause(2)
    .doIf(session => (session.contains("RedirectHomePage")) && (session.contains("Token")) ) {
      exec(http("IAPD_IndvlSrchResults_In_NBC")
      .post( BC_url+ """/Search/GenericSearch""")
      .headers(headers_bcsearch)
      .formParam( """GenericSearch.EmailAddress""", """STR3SS@FINRA.ORG""")
      .formParam( """__RequestVerificationToken""", """${Token}""")
      .formParam( """GenericSearch.StartRow""", """1""")
      .formParam( """GenericSearch.PageSize""", """15""")
      .formParam( """GenericSearch.System""", """BC""")
      .formParam( """GenericSearch.SearchType""", """1""")
      .formParam( """GenericSearch.IndividualSearchText""", """${viewIAIndvlRpt_BCLink}""")
      .formParam( """GenericSearch.EmploymingFirmSearchText""", """""")
      .formParam( """GenericSearch.FirmSearchText""", """""")
      .formParam( """GenericSearch.ZipCode""", """""")
      .formParam( """GenericSearch.Within""", """5""")
      .check(regex( """/Summary/(.*?)">Details""").find.optional.saveAs("hrefLink"))
      .check(currentLocation.optional.saveAs("Redirect_URI_BC"))
      .check(regex( """/Report/View/(.*?)/1""").find.optional.saveAs("Indvl_DetailReport"))
      )
    }
    .pause(2)
    /*
      .exec(http("AcceptTermsConditions_Get")
      .get("${Redirect_URI_BC}")
      .check(regex( """/Report/View/(.*?)/1""").find.optional.saveAs("Indvl_DetailReport")))
      .pause(2)
      .exec(http("AcceptTermsConditions_Post")
      .post(BC_url+"""/Support/TermsAndConditions""")
      .formParam( """accept""", """true""")
      .check(regex( """/Report/View/(.*?)/1""").find.optional.saveAs("Indvl_DetailReport")))
    */
    //.doIf(session => (session("Indvl_DetailReport").as[String] != "" )) {
    .doIf(session => (session.contains("Indvl_DetailReport"))){
      doIf(session => ThreadLocalRandom.current.nextInt(10) > 1) {
        exec(http("NBC_IndvlSrch_SummaryRpt")
        .get(BC_url+"/Report/View/"+"${Indvl_DetailReport}"+"/1")
        .check(regex( """id: "(.*)"""").saveAs("reportId")))
        .exec(http("NBC_IndvlSrch_DetailRpt_Status")
        .get(BC_url+"""/Report/Status""")
        .queryParam("id", "${reportId}"))
        .exec(http("NBC_IndvlSrch_DetailRpt_DownloadPDF")
        .get(BC_url+ """/Report/Download/${reportId}"""))
      }
    }
    .exec(flushSessionCookies)
    .exec(flushHttpCache)
    .exec(flushCookieJar)
  }
  private val SEO_IAPD = exitBlockOnFail {
    exec(http("SEO_IAPD_SiteMap")
    .get("http://iapd-stress.finra.org/IAPD/sitemap.aspx")
    .headers(Map("Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"))
    .check(regex("<sitemap><loc>(.*?)<").findAll.optional.saveAs("IndexList"))
    .check(regex("IndexSet=(.*?)<").findAll.optional.saveAs("IndexNum")))
    .doIf(session => session.contains("IndexList")) {
      foreach("${IndexList}", "IndexLink") {
        pause(1, 5)
        .exec(http("SEO_IAPD_IndexList")
        .get("${IndexLink}")
        // .get("${IndexList.random()}")
        .headers(Map("Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"))
        .check(regex("Individual/(.*?)<").findAll.optional.saveAs("Indvls"))
        .check(regex("Firm/(.*?)<").findAll.optional.saveAs("Firms"))
        )
        .pause(1, 5)
        .doIf(session => session.contains("Indvls")) {
          foreach("${Indvls}", "indvlLink") {
            exec(http("SEO_IAPD_IndividualLink")
              .get("http://iapd-stress.finra.org/IAPD/Individual/${indvlLink}")
              .headers(Map("Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"))
              .check(regex("${indvlLink}").find.optional.saveAs("indvlFound"))

            ).exec(session => if (!session.contains("indvlFound")) session.set("notFound", "notFound") else session.set("found", "indvlFound"))
          .exec{session =>  println("${found}")

              // return the original session
              session}
          }
        }
        //.pause(1, 5)
        /*.doIf(session => session.contains("Firms")) {
          foreach("${Firms}", "firmLink") {

            exec(http("SEO_IAPD_FirmLink")
              .get("http://iapd-stress.finra.org/IAPD/Firm/${firmLink}")
              .check(regex("${firmLink}").find.optional.saveAs("firmFound"))
            )
          }
        }*/
      }
    }
  }


  val 	IAPDIndvlSrch_Searchrequest_NOreport = scenario("IAPDIndvlSrch_Searchrequest_NOreport")
  .exitBlockOnFail {
    group("Homepage") {
      exec(IAPD_HomePage)
       // .exec(IAPD_SelectIndvlSearch)
    }
    .group("IndvlSearch") {
      exec(IAPD_IndvlSearch_multipleparameter)
    }
  }
  //default - Simple way to create the scenario for IAPD Firm search
  val snc_IAPD_FirmSearch = scenario("scn_IAPD_Firmsearches")
 // .repeat(10) {
    .feed(feeder_IPAD_Firm_data)
    .exec(search_IAPD_Firm)
    .pause(1)
 // }

  val IAPD_Firm = scenario("IAPD_FirmSearch_with_all_sections")
    // .during(totalDuration) ( // run for an 2 min
    //   pace(pacingtime) // start an iteration every 30 seconds
    .exec(snc_IAPD_FirmSearch)
   // .exec(IAPD_FirmSearch_GetLinks)
    .exec(ViewIAFirmRpt)
    //  .exec(CRD_IAPD.IPAD_BrokercheckLinkto_FirmSrch)
    .exec(flushSessionCookies)
    .exec(flushHttpCache)
  // )
  val IAPD_SEO = scenario("IAPD_SEO")
  .exec(SEO_IAPD)

  val scn_IAPD_IndvlSearch = scenario("scn_IAPD_Indvlsearches")
  //.repeat(10) {
    .feed(feeder_IPAD_Indvl_data)
    .exec(search_IAPD_Indvl)
    .pause(1)
  //}

  val pagination_indvl = scenario("click pagination for indvl search")
  .feed(feeder_IAPD_Indvl_search)
  .exec(pagination_indvl_search)

  val scn_IAPD_IndvlSearchonly = scenario("scn_IAPD_Indvlsearchesonly")
  .feed(feeder_IAPD_Indvl_search)
  .exec(search_IAPD_Indvlonly)

  private val hit_url = exitBlockOnFail{
    exec(http("IAPD_HomePage")
      .get(IAPD_url + """/""")
      .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"""))
      .check(regex("Welcome to the Investment Adviser Public Disclosure website").find.optional.saveAs("HomePageFound"))
      .check(CommonChecks_IAPD: _*)
    )
      .exec(session => if (session.contains("HomePageFound")) session else session.markAsFailed)
      .exitHereIfFailed
      .exec(
      http("hit url")
      .get(IAPD_url+ "/${url}")
      .check(regex("System Error").find.optional.saveAs("error"))
       /* .doIf(session => session.contains("error")) {
          url += "${url}"
        }*/
      )
      /*.doIf(session => session.contains("error")) {
        exec(url.concat("\n" + "${url}"))
      }*/
  }
 val scn_validate_urls = scenario("validate all urls")
  .repeat(1067) {
    feed(feeder_urls)
      .exec(hit_url)
  }

//IAPD INDVL view report
  val Indvl_ReportStatusLinks_Scrapping_QCR = exitBlockOnFail {
    feed(feeder_indvlReportLinkIds_qcr)
      .exec(http("ReportStatus_G")
        .get(IAPD_url_QCR +"/IAPD/Support/ReportStatus.aspx?")
        .queryParam("indvl_pk","${rptIAPD_IndvId}"))
  }
  //IAPD FIRM VIEW REPORT
  val Firm_BigDownloadPDF_QCR =exitBlockOnFail {
    feed(feeder_bigdownloadpdfFirmIds_QCR)
      .exec(http("IAPDFirmSummary_G")
        .get(IAPD_url_QCR + "/IAPD/IAPDFirmSummary.aspx?ORG_PK=${BigORG_PK}")
        .headers(Map("Upgrade-Insecure-Requests" -> "1"))
        .check(regex( """crd_iapd_stream_pdf""").find.optional.saveAs("gLastFormAdvFiled_cnt")))
      .pause(1)
      .doIf(session =>(session.contains("gLastFormAdvFiled_cnt"))){
        exec(http("crd_iapd_stream_pdf_G")
          .get(IAPD_url_QCR + "/IAPD/content/ViewForm/crd_iapd_stream_pdf.aspx?ORG_PK=${BigORG_PK}")
          .headers(Map("Upgrade-Insecure-Requests" -> "1"))
        )
      }
  }

  //nbc indvl view report
  val BC_indvl_searchreport_QCR =  exitBlockOnFail{
    exec(http("HOME_BC_G")
      .get(BC_url_QCR + """/""")
      .check(regex("""__RequestVerificationToken" type="hidden" value="(.*?)"""").find.saveAs("Token"))
    )
      .pause(2)
      .feed(feeder_BC_IndvlSearch_QCR)
      .exec(http("BC_IndvlSearch_byName_P")
        .post(BC_url_QCR +"""/Search/GenericSearch""")
        .headers(Map("""Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""","""Accept-Encoding""" -> """gzip, deflate""","""Cache-Control""" -> """max-age=0""","""Content-Type""" -> """application/x-www-form-urlencoded"""))
        .formParam( """GenericSearch.EmailAddress""",passwordQCR)
        .formParam( """__RequestVerificationToken""", """${Token}""")
        .formParam( """GenericSearch.StartRow""", """1""")
        .formParam( """GenericSearch.PageSize""", """15""")
        .formParam( """GenericSearch.System""", """BC""")
        .formParam( """GenericSearch.SearchType""", """1""")
        .formParam( """GenericSearch.IndividualSearchText""", """${bcSearchterm}""")
        .formParam( """GenericSearch.EmploymingFirmSearchText""", """""")
        .formParam( """GenericSearch.FirmSearchText""", """""")
        .formParam( """GenericSearch.Within""", """5""")
        .formParam( """GenericSearch.ZipCode""", """""")
        .check(regex( """ no results were found for""").find.optional.saveAs("NO_Results"))
        .check(regex( """ You must enter a valid search criteria for""").find.optional.saveAs("InvalidCriteria"))
        .check(regex( """/Individual/Summary/(.*?)"""").findAll.optional.saveAs("hrefLink"))
        // .check(css( """a.btn.btn-primary""", "data-url").findAll.optional.saveAs("link"))
        .check(status.is(200))
      )

      .doIf(session => (session.contains("bcSearchterm"))) {
        exec(session => {
          for {customers_IA <- session("bcSearchterm").validate[Seq[String]]
               val customer_IA = customers_IA(ThreadLocalRandom.current.nextInt(customers_IA.size))
          } yield session.set("ViewIndvlS", customer_IA)
          //    println("Random Indvl =" +session("ViewIndvlS").as[String])
          //    session
        }
        )
      }
      .doIf(session => !session.contains("NO_Results")) {
        doIf(session => session.contains("ViewIndvlS")){
          exec(http("AcceptTermsConditions_G")
            .get(BC_url_QCR+"/Individual/Summary/"+"${ViewIndvlS}")
            .check(regex( """/Report/View/(.*?)/1""").find.optional.saveAs("Indvl_DetailReport")))
            .exec(http("AcceptTermsConditions_P")
              .post(BC_url_QCR+"""/Support/TermsAndConditions""")
              .formParam( """accept""", """true""")
              .check(regex( """/Report/View/(.*?)/1""").find.optional.saveAs("Indvl_DetailReport")))
            .doIf(session => ThreadLocalRandom.current.nextInt(10) > 1) {
              doIf(session => (session("Indvl_DetailReport").as[String] != "" )) {
                exec(http("BC_IndvlSrch_SummaryRpt_G")
                  .get(BC_url_QCR+"/Report/View/"+"${Indvl_DetailReport}"+"/1")
                  .check(regex( """id: "(.*)"""").saveAs("reportId")))
                  //  .group("BC_IndvlSrch_DetailRpt_G") {
                  .exec(http("BC_IndvlSrch_DetailRpt_Status_G")
                  .get(BC_url_QCR+ """/Report/Status""")
                  .queryParam("id", "${reportId}"))
                  .exec(http("BC_IndvlSrch_DetailRpt_DownloadPDF_G")
                    .get( BC_url_QCR+"""/Report/Download/${reportId}"""))
                //  }
              }
            }
        }
      }
  }


  //nbc firm view report
  val BC_Firm_searchreport_QCR =  exitBlockOnFail{
    exec(http("HOME_BC_G")
      .get(BC_url_QCR + """/""")
      .check(regex("""__RequestVerificationToken" type="hidden" value="(.*?)"""").find.saveAs("Token"))
    )
      .pause(2)
      .feed(feeder_BC_FirmSearch_QCR)
      .exec(http("BC_FirmSearch_byName_P")
        .post(BC_url_QCR +"""/Search/GenericSearch""")
        .headers(Map("""Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""","""Accept-Encoding""" -> """gzip, deflate""","""Cache-Control""" -> """max-age=0""","""Content-Type""" -> """application/x-www-form-urlencoded"""))
        .formParam( """GenericSearch.EmailAddress""", passwordQCR)
        .formParam( """__RequestVerificationToken""", """${Token}""")
        .formParam( """GenericSearch.StartRow""", """1""")
        .formParam( """GenericSearch.PageSize""", """15""")
        .formParam( """GenericSearch.System""", """BC""")
        .formParam( """GenericSearch.SearchType""", """2""")
        .formParam( """GenericSearch.IndividualSearchText""", """""")
        .formParam( """GenericSearch.EmploymingFirmSearchText""", """""")
        .formParam( """GenericSearch.FirmSearchText""", """${bcFirmSearchterm}""")
        .formParam( """GenericSearch.Within""", """5""")
        .formParam( """GenericSearch.ZipCode""", """""")
        .check(regex( """ no results were found for""").find.optional.saveAs("NO_Results"))
        .check(regex( """ You must enter a valid search criteria for""").find.optional.saveAs("InvalidCriteria"))
        .check(regex( """/Firm/Summary/(.*?)"""").findAll.optional.saveAs("fhrefLink"))
        //.check(css( """a.btn.btn-primary""", "data-url").findAll.optional.saveAs("link"))
        .check(status.is(200))
      )
      .doIf(session => (session.contains("fhrefLink"))) {
        exec(session => {
          for {customers_IA <- session("fhrefLink").validate[Seq[String]]
               val customer_IA = customers_IA(ThreadLocalRandom.current.nextInt(customers_IA.size))
          } yield session.set("ViewFirmS", customer_IA)
          //    println("Random Indvl =" +session("ViewIndvlS").as[String])
          //    session
        }
        )
      }

      .doIf(session => !session.contains("NO_Results")) {
        doIf(session => session.contains("ViewFirmS")){
          exec(http("AcceptTermsConditions_G")
            .get(BC_url_QCR+"/Firm/Summary/"+"${ViewFirmS}")
            .check(regex( """/Report/View/(.*?)/2""").find.optional.saveAs("Firm_DetailReport")))
            .exec(http("AcceptTermsConditions_P")
              .post(BC_url_QCR+"""/Support/TermsAndConditions""")
              .formParam( """accept""", """true""")
              .check(regex( """/Report/View/(.*?)/2""").find.optional.saveAs("Firm_DetailReport")))
            //.doIf(session => ThreadLocalRandom.current.nextInt(10) > 1) {
            .doIf(session => (session("Firm_DetailReport").as[String] != "" )) {
            exec(http("BC_FirmSrch_SummaryRpt_G")
              .get(BC_url_QCR+"/Report/View/"+"${Firm_DetailReport}"+"/2")
              .check(regex( """id: "(.*)"""").saveAs("freportId")))
              //  .group("BC_FirmSrch_DetailRpt_G") {
              .exec(http("BC_FirmSrch_DetailRpt_Status")
              .get(BC_url_QCR+ """/Report/Status""")
              .queryParam("id", "${freportId}"))
              .exec(http("BC_FirmSrch_DetailRpt_DownloadPDF_G")
                .get( BC_url_QCR+"""/Report/Download/${freportId}"""))
            // }
            //}
          }
        }
      }
  }
//qcr bc click disclosure links
val BC_Indvidualsrch_Summary_DisclosureLinks =  exitBlockOnFail {
  exec(http("BC_HomePage_G")
    .get(BC_url_QCR + """/""")
    .check(regex( """__RequestVerificationToken" type="hidden" value="(.*?)"""").find.saveAs("Token"))
    )
    .pause(2)
    .feed(feeder_BC_IndvlSearch_QCR)
    .exec(http("BC_GenericSearch_Indvlby_Name_P")
      .post(BC_url_QCR + """/Search/GenericSearch""")
      .headers(Map( """Accept""" -> """text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8""", """Accept-Encoding""" -> """gzip, deflate""", """Cache-Control""" -> """max-age=0""", """Content-Type""" -> """application/x-www-form-urlencoded"""))
      .formParam( """GenericSearch.EmailAddress""", passwordQCR)
      .formParam( """__RequestVerificationToken""", """${Token}""")
      .formParam( """GenericSearch.StartRow""", """1""")
      .formParam( """GenericSearch.PageSize""", """15""")
      .formParam( """GenericSearch.System""", """BC""")
      .formParam( """GenericSearch.SearchType""", """1""")
      .formParam( """GenericSearch.IndividualSearchText""", """${bcSearchterm}""")
      .formParam( """GenericSearch.EmploymingFirmSearchText""", """""")
      .formParam( """GenericSearch.FirmSearchText""", """""")
      .formParam( """GenericSearch.Within""", """15""")
      .formParam( """GenericSearch.ZipCode""", """""")
    )
    // .repeat(1) {
    .feed(feeder_BC_IndvlSearch_QCR)
    .exec(http("BC_Indvl_SummaryPage_G")
      .get(BC_url_QCR + "/Individual/Summary/${bcSearchterm}")
      .check(regex( """<tr id="(.*?)" style="display: none;" class="ListItemColor">""").findAll.optional.saveAs("indDislinks"))
    )
    .pause(1)
    .doIf(session => (session.contains("indDislinks"))) {
      //          exec(session => {
      //            for {customers_IA <- session("indDislinks").validate[Seq[String]]
      //                 val customer_IA = customers_IA(ThreadLocalRandom.current.nextInt(customers_IA.size))
      //            } yield session.set("ViewIndvDiscS", customer_IA)
      //            //    println("Random ViewIndvDiscS ID =" +session("ViewIndvDiscS").as[String])
      //            //    session
      //          }
      //          )
      foreach("${indDislinks}", "indDislink") {
        exec(http("Individual_DisclosureDetails_G")
          .post(BC_url_QCR + "/Individual/DisclosureDetails")
          .headers(Map("Accept" -> "*/*", "Accept-Encoding" -> "gzip, deflate", "X-Requested-With" -> "XMLHttpRequest"))
          //.formParam("id", "${ViewIndvDiscS}"))
          .formParam("id", "${indDislink}"))
          .pause(1)
      }
    }
}
  val scn_IAPD_IndvlDownloadReport_Scrapping_QCR = scenario("IAPD_IndvlDownloadReport_ScrappingQCR")
    .exec(Indvl_ReportStatusLinks_Scrapping_QCR)
  val scn_IAPD_Firm_BigDownloadPDF_QCR = scenario("IAPD_FirmBigDownloadPDFQCR")
    .exec(Firm_BigDownloadPDF_QCR)
  val scn_BC_IndvlSearchReport_QCR = scenario("scn_BC_IndvlsearchesReportZipQCR")
    .exec(BC_indvl_searchreport_QCR)

  val scn_BC_FirmSearchReport_QCR = scenario("scn_BC_Firmsearches_QCR")
    .exec(BC_Firm_searchreport_QCR)

  val scn_BC_IndvlSummaryDisclosureLinks = scenario("BC_IndvlSummaryDisclosureLinks")
    .exec(BC_Indvidualsrch_Summary_DisclosureLinks)
  def ReadablizeBytes (bytes:Int):String = {
    val s = Array("bytes", "kb", "MB", "GB", "TB", "PB")
    val e: Int = (Math.floor(Math.log(bytes) / Math.log(1024))).toInt
    val value = bytes/Math.pow(1024,Math.floor(e))
    return ((value * 1000).round / 1000.toDouble) + " " + s(e)
  }


  /* user define fuction which will make a decision depending on the given string and split out integer value either 1 or 2*/
  def returnLinkValue(linkString: String): Int = {
    println("final link = "+ linkString )
    if (linkString.startsWith("http")) return 1
    else 2
  }
  /* User define function to return the id based on the pattern provided to the function and its split by = */
  def returnId (str:String, str2: String):String = {
    val pattern = str2.r
    val Id = (pattern findAllIn str).mkString("").split("=").last
    Id
  }
  /* User define function to return the id based on the pattern provided to the function and its split by = */
  def returnFirm (str:String):String = {
    val pattern = """(FirmID=\d+)""".r
    val firmId = (pattern findAllIn str).mkString("").split("=").last
    firmId
  }
  /* User define function to return the id based on the pattern provided to the function and its split by = */
  def returnIndvl (str:String):String = {
    val pattern = """(IndividualID=\d+)""".r
    val indvlId = (pattern findAllIn str).mkString("").split("=").last
    indvlId
  }

  def returnSection (str:String):String = {
    val pattern = """/Sections/(.*).aspx""".r
    val Section = (pattern findAllIn str).mkString("").split("/").last
    Section

  }

  def returnSectionStreamPDF (str:String):String = {
    val pattern = """ViewForm/crd(.*).aspx""".r
    val Section = (pattern findAllIn str).mkString("").split("/").last
    Section
  }


  def returnformversion (str:String):String = {
    val pattern = """iapd/content/viewform/(.*?)""".r
    val Section = (pattern findAllIn str).mkString("").split("/").last
    Section
  }

  def getRandom(i: Int) : Int = ThreadLocalRandom.current.nextInt(i).toInt
  def systemtime(i:Int) :String = System.currentTimeMillis.toString
  def getRand(i: Int) : String = ThreadLocalRandom.current.nextInt(i).toString


}  // close the object